# Repo Map

## Root
- `FEDERATED_NODE.md` — authoritative topology statement
- `CLEARINGHOUSE_CLUSTER.md` — cluster model
- `REPO_MAP.md` — this file

## Docs
- `docs/architecture/` — why the system is shaped the way it is
- `docs/build/` — build procedures and host-specific install notes
- `docs/ops/` — service map, startup order, replication, users, and ports
- `docs/security/` — key and trust notes

## Hosts
- `hosts/intel-primary/` — primary host notes and scripts
- `hosts/m4-secondary/` — secondary host notes and scripts

## Node roles
- `node/federated-primary/`
- `node/clearinghouse-primary/`
- `node/clearinghouse-secondary/`
- `node/counterparty/`
- `node/bridge/`
- `node/audit/`

## Scripts
- `scripts/bootstrap/` — repo bootstrap helpers
- `scripts/build/` — build helpers
- `scripts/sync/` — config/state synchronization
- `scripts/start/` — start helpers
- `scripts/stop/` — stop helpers
- `scripts/verify/` — verification and comparison helpers
- `scripts/vm/` — VM setup helpers
