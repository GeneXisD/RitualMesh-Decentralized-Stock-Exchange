# Service Map

## RitualMesh DSE dual-host service map

### Primary
- Host: Intel Mac
- Guest: Ubuntu 14.04.6
- Role: primary federated node
- Authority: canonical

### Secondary
- Host: M4 Mac
- Role: secondary ClearingHouse support host
- Authority: non-canonical unless promoted

## Ownership table

| Service / Role | Intel Ubuntu 14.04 | M4 Mac | Notes |
|---|---|---|---|
| Federated node identity | Primary | No | Intel is authoritative |
| ClearingHouse primary | Primary | Secondary / mirror | Intel is canonical |
| Counterparty interaction | Primary | Validation only | Keep Intel authoritative |
| Wallet/backend binding | Primary | Optional tools | Avoid accidental dual-writes |
| Audit / verification | Optional | Primary | Best fit on M4 |
| Reverse-repo support | Optional bridge | Primary support | M4 assists without becoming node identity |
| Config archive / snapshots | Primary source | Secondary copy | Keep both sides documented |

## Rule
Both hosts may run ClearingHouse-capable components, but only the Ubuntu 14.04 primary is the canonical federated node.
