# Host Roles

## Intel primary
- primary federated host
- Ubuntu 14.04 VM
- canonical ports
- canonical credentials
- canonical write path

## M4 secondary
- support host
- secondary ClearingHouse-capable environment
- config mirror
- audit and sync
- recovery and migration support

## Rule
Do not describe both hosts as equal federated identities.
