# Reverse Repo

## Current architectural position
Reverse-repo support belongs around the dual-host model, not inside the primary node identity itself.

## Recommended flow
reverse-repo support
-> bridge services
-> comparison / validation
-> canonical ClearingHouse state
-> settlement / audit confirmation

## Placement
- support logic and orchestration may run on the M4 host
- authoritative execution remains on the Intel Ubuntu 14.04 primary unless explicitly changed
